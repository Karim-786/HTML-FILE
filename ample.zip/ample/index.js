document.addEventListener('DOMContentLoaded', function () {
    const ctaButton = document.querySelector('.cta-button');
    const slotStatus = document.createElement('h3');
    const modal = document.getElementById('myModal');
    const closeBtn = document.querySelector('.close');
    const warningMessage = document.createElement('p'); 

    ctaButton.parentNode.insertBefore(slotStatus, ctaButton);


    function openModal() {
        modal.style.display = 'block';
    }

    function closeModal() {
        modal.style.display = 'none';
    }

    async function checkGoogleFormStatus() {
        const scriptUrl = 'https://script.google.com/macros/s/AKfycbwNFMqL61iNgL3RGVum9UT6S_NzoGCFDVPTnCVKmR4qYqRXMqHNlTsw7XYaYVqoMill-g/exec'; 

        try {
            const response = await fetch(scriptUrl);
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            const data = await response.json();
            if (data.status === 'available') {
                slotStatus.textContent = 'Slots Available';
                enableRegisterButton();  
            } else {
                slotStatus.textContent = 'Slots Unavailable';
                disableRegisterButton();  
                showWarning('Warning: Slots are currently unavailable.');
            }
        } catch (error) {
            console.error("Error fetching form status:", error);
            slotStatus.textContent = 'Error fetching form status. Please try again later.';
            disableRegisterButton();
            showWarning('Warning: Unable to check form status. Please try again later.');
        }
    }

    function disableRegisterButton() {
        ctaButton.classList.add('disabled');
        ctaButton.style.pointerEvents = 'none';
        ctaButton.style.opacity = '0.5';
        ctaButton.style.cursor = 'not-allowed';
        ctaButton.removeAttribute('href');
        ctaButton.addEventListener('click', handleModalOpen);
    }

    function enableRegisterButton() {
        ctaButton.classList.remove('disabled');
        ctaButton.style.pointerEvents = 'auto';
        ctaButton.style.opacity = '1';
        ctaButton.style.cursor = 'pointer';
        ctaButton.href = 'https://forms.gle/92STqvQGxjMLsRrZ7'; // Google Form link
        ctaButton.removeEventListener('click', handleModalOpen);
    }

    function handleModalOpen(event) {
        event.preventDefault();
        openModal();
    }

    function showWarning(message) {

        warningMessage.textContent = message;
    

        warningMessage.style.backgroundColor = '#3d4e57'; 
        warningMessage.style.color = '#ffd700'; 
        warningMessage.style.fontWeight = 'bold';
        warningMessage.style.marginTop = '20px';
        warningMessage.style.padding = '15px'; 
        warningMessage.style.borderRadius = '8px'; 
        warningMessage.style.border = '1px solid #ffd700'; 
        warningMessage.style.textAlign = 'center'; 
        warningMessage.style.boxShadow = '0px 4px 8px rgba(0, 0, 0, 0.2)'; 
    
        modal.querySelector('.modal-content').appendChild(warningMessage);
    
        openModal();
    }
    

    closeBtn.addEventListener('click', closeModal);
    
  
    window.addEventListener('click', function (e) {
        if (e.target === modal) {
            closeModal();
        }
    });

    checkGoogleFormStatus();
});
